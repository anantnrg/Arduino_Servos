/* Written by Anant Narayan for controlling multiple servos with Arduino via Platform IO.In this code the servos are 
assinged to PWM pins 3 and 5 respectively.*/

#include <Arduino.h>
#include <Servo.h>

Servo servo1; 
Servo servo2;

int servo_position = 0;

void setup() {
  servo1.attach(3);
  servo2.attach(5); 
 
}

void loop() {
  for (servo_position = 0; servo_position < 180; servo_position++) { 
    servo1.write(servo_position);              
    servo2.write(servo_position);       
    delay(10);                      
  }
  for (servo_position = 180; servo_position > 0; servo_position--) { 
    servo1.write(servo_position);                
    servo2.write(servo_position);             
    delay(10);                      
  }

}
